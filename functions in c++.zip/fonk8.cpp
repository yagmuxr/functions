#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
int ebob(int sayi1, int sayi2){
	int buyukSayi;
	if(sayi1>sayi2) {
		buyukSayi = sayi1;
	} else {
		buyukSayi = sayi2;
	}
	
	for(buyukSayi; buyukSayi>0; buyukSayi--) {
		if( (sayi1%buyukSayi==0) && (sayi2%buyukSayi==0) ) {
			cout << "EBOB: " << buyukSayi;
			break;
			return buyukSayi;
		}
	}
}
int main()
{
	setlocale(LC_ALL, "Turkish");
	int sayi11, sayi22;
	cout<< "Birinci say�y� giriniz: ";
	cin>>sayi11;
	cout<<"�kinci say�y� giriniz: ";
	cin>>sayi22;
	int sonuc = ebob(sayi11, sayi22);
}

