#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
int ekok(int sayi1, int sayi2){
	for(int i=1; i<=sayi1*sayi2; i++) {
		if( (i%sayi1==0) && (i%sayi2==0) ){
			cout << "EKOK: " << i;
			break;
		}
	}
}


int main()
{
	setlocale(LC_ALL, "Turkish");
	int sayi11, sayi22;
	cout<< "Birinci say�y� giriniz: ";
	cin>>sayi11;
	cout<<"�kinci say�y� giriniz: ";
	cin>>sayi22;
	int sonuc = ekok(sayi11, sayi22);
}

