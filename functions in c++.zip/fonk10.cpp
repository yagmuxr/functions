#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
#include "odev.h"
#include <conio.h>
using namespace std;
int main(){
	setlocale(LC_ALL, "Turkish");
	int sayi11, sayi22;
	char cvp;
	cout << "Birinci say�y� giriniz: ";
	cin>>sayi11;
	cout<< "�kinci say�y� giriniz: ";
	cin>>sayi22;
	cout<< "EBOB mu bulmak istiyorsunuz EKOK mu?(ebob i�in 1, ekok i�in 2 giriniz.) ";
	cvp=getche();
	switch (cvp)
	{
		case '1' : {
			cout << "��lem sonucu: " << ebob(sayi11, sayi22);
			break;
		}
		case '2' :{
			cout << "��lem sonucu: " << ekok(sayi11, sayi22);
			break;
		}
		default : cout << "Hatal� giri� yapt�n�z. ";
	}
	
	
}
