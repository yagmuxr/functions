#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;

int main()
{
setlocale(LC_ALL, "Turkish");	
int sayi11,sayi22, veri;
void sayiuret(int, int);
cout<<"Birinci say�y� giriniz: ";
cin>>sayi11;
cout<<"�kinci say�y� giriniz: ";
cin>>sayi22;
sayiuret(sayi11,sayi22);
}
void sayiuret(int sayi1,int sayi2)
{
	int sonuc[50];
	srand(time(NULL));
	for(int i=0; i<50; i++){
	sonuc[i]= rand() % (sayi1-sayi2)+sayi2;  
}
for(int j=0; j<50; j++){
	cout << sonuc[j] << "\n"; 
}
}
