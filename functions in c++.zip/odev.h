int ekok(int sayi1, int sayi2){
	for(int i=1; i<=sayi1*sayi2; i++) {
		if( (i%sayi1==0) && (i%sayi2==0) ){
			return i;
			break;
		}
	}
}
int ebob(int sayi1, int sayi2){
	int buyukSayi;
	if(sayi1>sayi2) {
		buyukSayi = sayi1;
	} else {
		buyukSayi = sayi2;
	}
	
	for(buyukSayi; buyukSayi>0; buyukSayi--) {
		if( (sayi1%buyukSayi==0) && (sayi2%buyukSayi==0) ) {
			return buyukSayi;
			break;
		}
	}
}
