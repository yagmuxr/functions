#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
void terstenyaz(string cumle){
for (int i = cumle.size(); i>= 0; i--) 
cout << cumle[i];
}
int main(){
	setlocale(LC_ALL, "Turkish");
	string girdi;
	cout<<"Bir c�mle giriniz: ";
	getline(cin,girdi);
	terstenyaz(girdi);
}
