#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
void rakamlarisil(string cumle){  
	for(int i=0; i<= cumle.size();i++){ 
    if(cumle[i]>='0' && cumle[i]<='9'){ 
    cout<<"C�mledeki rakam: "<< cumle[i] << "\n" ; 
	cumle.replace(i,1, " "); 
	} 
    } 
    cout<<"Yeni c�mle: "<< cumle << "\n" ;  
}
int main(){
	string girdi;
	setlocale(LC_ALL, "Turkish");
	cout << "Bir c�mle giriniz: ";
	getline(cin,girdi);
	rakamlarisil(girdi);
}
