#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
#include <iomanip>
#include <conio.h>
using namespace std;
const int satir=3;
const int sutun=3;
void matrisegir(int A[satir][sutun]);
void matristopla(int A[satir][sutun], int B[satir][sutun]);
int main()
{
setlocale(LC_ALL, "Turkish");
int X[satir][sutun], Y[satir][sutun]; 
matrisegir(X);
matrisegir(Y);
matristopla(X, Y);
}
void matrisegir(int A[satir][sutun]){
int satir, sutun;	  
for (int i = 0; i < satir ; i++){
     for (int j = 0; j < sutun ; j++){ 
	     cout <<  i + 1<<". sat�r " << j + 1 << ". sut�n: "; 
		 cin >> A[i][j]; 
		 } 
	}
}
void matristopla(int A[satir][sutun], int B[satir][sutun]){ 
int C[satir][sutun];
for (int i = 0; i < satir; i++) {
    for (int j = 0; j <sutun; j++) { 
    C[i][j] = A[i][j] + B[i][j]; 
   }
        } 

    cout << "A+B=\n"; 

    for (int i = 0; i < satir; i++) { 

        for (int j = 0; j < sutun; j++) 

            cout << C[i][j] << "  "; 

         

}
}

