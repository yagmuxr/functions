#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
float artort(int veri[30]){
	int toplam=0, sonuc;
	for(int i=0; i<30; i++){
	toplam+=veri[i];
	}
	sonuc = toplam / 30;
	return sonuc;
}
void minmaks(int veri[30]){
int buyuk=veri[0]; 
int kucuk=veri[0];
for(int i = 0; i <30; i++){ 
if(veri[i]>buyuk); 
{ 
buyuk=veri[i]; 
} 
if(veri[i]<kucuk) 
{ 
kucuk=veri[i]; 
}
}    
    cout<<"En K���k Say� :  "<<kucuk<< "\n"; 
	cout<<"En B�y�k Say� :  "<<buyuk<< "\n"; 
}
void ciftler(int veri[30]){
for(int l=0; l<30; l++){  
if(veri[l]%2==0){  
cout << "�ift Say�lar: " <<veri[l] << "\n";  
}
}
}
void tekler(int veri[30]){
for (int x=0 ; x<30 ; x++){
if(veri[x]%2!=0){
cout << "Tek Say�lar: " << veri[x] << "\n" ;  
}  
} 
}
int main(){
	setlocale(LC_ALL, "Turkish");
	srand(time(NULL));
	int girdi[30], sonuc1;
	for(int m=0; m<30; m++){
	girdi[m]= rand() % 100 + 1;	
	}
sonuc1=artort(girdi);
minmaks(girdi);
ciftler(girdi);
tekler(girdi);
}

