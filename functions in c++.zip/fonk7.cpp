#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
int basamaktopla(int i){
	if (i<0){
		cout<< "Girdi�iniz say� negatif.";
	}
	if(i>=0 && i<10){
		return i;
	}
	else{
		int temp = basamaktopla(i/10);
		
		return temp + i % 10;
	}
}
int main(){
	int sayi;
	setlocale(LC_ALL, "Turkish");
	cout << "Bir say� giriniz: ";
	cin>>sayi;
	int sonuc= basamaktopla(sayi);
	cout << "Sonu�: " << sonuc ;
}
