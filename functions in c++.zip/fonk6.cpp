#include<iostream>
#include<stdlib.h>
#include<time.h>
#include<locale.h>
using namespace std;
void basamakyazdir(int x){
	if( x>=0 && x<=9){
		cout << x;
	}
	else {
		basamakyazdir(x/10);
		cout << x % 10 << endl;
	
	}
}
int main(){
	setlocale(LC_ALL,"Turkish");
	int veri;
	cout << "Bir say� giriniz: ";
	cin>>veri;
	basamakyazdir(veri);
}
